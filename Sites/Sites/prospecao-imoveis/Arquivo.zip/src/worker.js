// ── Helpers ────────────────────────────────────────────────────
function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}

function rowToObj(row) {
  if (!row) return null;
  return {
    ...row,
    telefones: JSON.parse(row.telefones || '[]'),
    fotos:     JSON.parse(row.fotos     || '[]'),
  };
}

function uuid() {
  return crypto.randomUUID().replace(/-/g, '');
}

const ALLOWED_TYPES = ['image/jpeg','image/png','image/webp','image/gif'];
const EXT_MAP = { 'image/jpeg':'jpg', 'image/png':'png', 'image/webp':'webp', 'image/gif':'gif' };

// ── Router ─────────────────────────────────────────────────────
export default {
  async fetch(request, env) {
    const url  = new URL(request.url);
    const path = url.pathname;
    const method = request.method;

    // ── R2 uploads ──────────────────────────────────────────────
    if (path.startsWith('/uploads/')) {
      if (!env.R2) return new Response('R2 não configurado', { status: 503 });
      const key = path.replace('/uploads/', '');
      if (method === 'GET') {
        const obj = await env.R2.get(key);
        if (!obj) return new Response('Not found', { status: 404 });
        const headers = new Headers();
        obj.writeHttpMetadata(headers);
        headers.set('Cache-Control', 'public, max-age=31536000');
        return new Response(obj.body, { headers });
      }
      return new Response('Method not allowed', { status: 405 });
    }

    // ── API routes ──────────────────────────────────────────────
    if (path.startsWith('/api/')) {

      // GET /api/dashboard
      if (path === '/api/dashboard' && method === 'GET') {
        const [tot, prosp, nao, tipos] = await Promise.all([
          env.DB.prepare('SELECT COUNT(*) as n FROM imoveis_prospectados').first(),
          env.DB.prepare("SELECT COUNT(*) as n FROM imoveis_prospectados WHERE status='prospectado'").first(),
          env.DB.prepare("SELECT COUNT(*) as n FROM imoveis_prospectados WHERE status='nao_prospectado'").first(),
          env.DB.prepare('SELECT tipo, COUNT(*) as cnt FROM imoveis_prospectados GROUP BY tipo').all(),
        ]);
        const por_tipo = {};
        (tipos.results || []).forEach(r => { por_tipo[r.tipo] = r.cnt; });
        return json({ total: tot.n, prospectado: prosp.n, nao_prospectado: nao.n, por_tipo });
      }

      // GET /api/imoveis
      if (path === '/api/imoveis' && method === 'GET') {
        let sql = 'SELECT * FROM imoveis_prospectados WHERE 1=1';
        const params = [];
        const status = url.searchParams.get('status');
        const tipo   = url.searchParams.get('tipo');
        if (status) { sql += ' AND status=?'; params.push(status); }
        if (tipo)   { sql += ' AND tipo=?';   params.push(tipo); }
        sql += ' ORDER BY created_at DESC';
        const { results } = await env.DB.prepare(sql).bind(...params).all();
        return json(results.map(rowToObj));
      }

      // POST /api/imoveis
      if (path === '/api/imoveis' && method === 'POST') {
        const data = await request.json();
        const stmt = env.DB.prepare(`
          INSERT INTO imoveis_prospectados
            (lat, lng, endereco, tipo, status, proprietario, telefones, observacoes)
          VALUES (?,?,?,?,?,?,?,?)
        `).bind(
          data.lat || 0, data.lng || 0,
          data.endereco || '',
          data.tipo || 'casa',
          data.status || 'nao_prospectado',
          data.proprietario || '',
          JSON.stringify(data.telefones || []),
          data.observacoes || '',
        );
        const result = await stmt.run();
        const row = await env.DB.prepare('SELECT * FROM imoveis_prospectados WHERE id=?')
          .bind(result.meta.last_row_id).first();
        return json(rowToObj(row), 201);
      }

      // /api/imoveis/:id
      const matchId = path.match(/^\/api\/imoveis\/(\d+)$/);
      if (matchId) {
        const id = parseInt(matchId[1]);

        // GET
        if (method === 'GET') {
          const row = await env.DB.prepare('SELECT * FROM imoveis_prospectados WHERE id=?').bind(id).first();
          if (!row) return json({ error: 'Not found' }, 404);
          return json(rowToObj(row));
        }

        // PUT
        if (method === 'PUT') {
          const data = await request.json();
          const cur  = await env.DB.prepare('SELECT * FROM imoveis_prospectados WHERE id=?').bind(id).first();
          if (!cur) return json({ error: 'Not found' }, 404);
          await env.DB.prepare(`
            UPDATE imoveis_prospectados SET
              endereco=?, tipo=?, status=?, proprietario=?,
              telefones=?, observacoes=?,
              updated_at=datetime('now','localtime')
            WHERE id=?
          `).bind(
            data.endereco    ?? cur.endereco,
            data.tipo        ?? cur.tipo,
            data.status      ?? cur.status,
            data.proprietario?? cur.proprietario,
            JSON.stringify(data.telefones ?? JSON.parse(cur.telefones || '[]')),
            data.observacoes ?? cur.observacoes,
            id,
          ).run();
          const updated = await env.DB.prepare('SELECT * FROM imoveis_prospectados WHERE id=?').bind(id).first();
          return json(rowToObj(updated));
        }

        // DELETE
        if (method === 'DELETE') {
          const row = await env.DB.prepare('SELECT fotos FROM imoveis_prospectados WHERE id=?').bind(id).first();
          if (row && env.R2) {
            const fotos = JSON.parse(row.fotos || '[]');
            await Promise.all(fotos.map(f => env.R2.delete(f.replace('/uploads/', ''))));
          }
          await env.DB.prepare('DELETE FROM imoveis_prospectados WHERE id=?').bind(id).run();
          return json({ ok: true });
        }
      }

      // POST /api/imoveis/:id/fotos
      const matchFoto = path.match(/^\/api\/imoveis\/(\d+)\/fotos$/);
      if (matchFoto && method === 'POST') {
        if (!env.R2) return json({ error: 'R2 não configurado — ative no dashboard Cloudflare' }, 503);
        const id  = parseInt(matchFoto[1]);
        const row = await env.DB.prepare('SELECT * FROM imoveis_prospectados WHERE id=?').bind(id).first();
        if (!row) return json({ error: 'Not found' }, 404);

        const formData = await request.formData();
        const file = formData.get('foto');
        if (!file || !ALLOWED_TYPES.includes(file.type))
          return json({ error: 'Tipo de arquivo não permitido' }, 400);

        const ext      = EXT_MAP[file.type] || 'jpg';
        const filename = `${uuid()}.${ext}`;
        await env.R2.put(filename, await file.arrayBuffer(), {
          httpMetadata: { contentType: file.type },
        });

        const fotos = JSON.parse(row.fotos || '[]');
        fotos.push(`/uploads/${filename}`);
        await env.DB.prepare(
          "UPDATE imoveis_prospectados SET fotos=?, updated_at=datetime('now','localtime') WHERE id=?"
        ).bind(JSON.stringify(fotos), id).run();
        const updated = await env.DB.prepare('SELECT * FROM imoveis_prospectados WHERE id=?').bind(id).first();
        return json(rowToObj(updated), 201);
      }

      // DELETE /api/imoveis/:id/fotos/:idx
      const matchFotoIdx = path.match(/^\/api\/imoveis\/(\d+)\/fotos\/(\d+)$/);
      if (matchFotoIdx && method === 'DELETE') {
        if (!env.R2) return json({ error: 'R2 não configurado' }, 503);
        const id  = parseInt(matchFotoIdx[1]);
        const idx = parseInt(matchFotoIdx[2]);
        const row = await env.DB.prepare('SELECT * FROM imoveis_prospectados WHERE id=?').bind(id).first();
        if (!row) return json({ error: 'Not found' }, 404);
        const fotos = JSON.parse(row.fotos || '[]');
        if (idx < 0 || idx >= fotos.length) return json({ error: 'Índice inválido' }, 400);
        await env.R2.delete(fotos[idx].replace('/uploads/', ''));
        fotos.splice(idx, 1);
        await env.DB.prepare(
          "UPDATE imoveis_prospectados SET fotos=?, updated_at=datetime('now','localtime') WHERE id=?"
        ).bind(JSON.stringify(fotos), id).run();
        const updated = await env.DB.prepare('SELECT * FROM imoveis_prospectados WHERE id=?').bind(id).first();
        return json(rowToObj(updated));
      }

      return json({ error: 'Not found' }, 404);
    }

    // ── Static assets (index.html via Workers Assets) ───────────
    return env.ASSETS.fetch(request);
  },
};
